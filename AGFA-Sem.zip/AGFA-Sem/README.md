# SEM-Master
Templates für kleinere Ausarbeitungen, etwa für Seminare in der AGFA
